/*two processes communicating both ways by using two pipes.
one process read input from the user and handles it. the other
process make some translation of the input(translates upprt-case letters to
lower-case) and hands it back to the first process for printing
*/

#include <stdio.h>
#include <unistd.h>
#include <ctype.h>
#include <stdlib.h>

//function executed by the user-interaction process
void user_handler(int input_pipe[], int output_pipe[]){
	int c; //user input
	int rc; //return values of functions

	close(input_pipe[1]);
	close(output_pipe[0]);
//loop read input from user, send via one pipe to the translator
	while((c=getchar())>0){
		//write to translar
		rc=write(output_pipe[1],&c,1);
		if(rc==-1){
			perror("user_handler: write");
		close(input_pipe[0]);
		close(output_pipe[1]);
		exit(1);
		}
		//read back from translator
		rc=read(input_pipe[0],&c,1);
		if(rc<=0){
			perror("user_handler: read");
			close(input_pipe[0]);
			close(output_pipe[1]);
			exit(1);
		}
		//print translated charactor to stdout
		putchar(c);
	}
	//close pipes and exit
	close(input_pipe[0]);
	close(output_pipe[1]);
	exit(0);
	}
	//function executed by the translator process
	void translator(int input_pipe[],int output_pipe[]){
		int c;
		int rc;

	close(input_pipe[1]);
	close(output_pipe[0]);
//loop of reading from user_handler's pipe trnslating
	while(read(input_pipe[0],&c,1)>0){
	//upper-case to lower-case
		if(isascii(c)&& isupper(c))
			c=tolower(c);
	//write translated character back to user_handler
		rc=write(output_pipe[1], &c,1);
		if(rc==-1){
			perror("translator: write");
			close(input_pipe[0]);
			close(output_pipe[1]);
			exit(1);
		}
	}

	close(input_pipe[0]);
	close(output_pipe[1]);
	exit(0);
	}

	int main(int argc, char* argv[]){
//two arrays to contain file descriptor for two pipes
		int user_to_translator[2];
		int translator_to_user[2];
		int pid;
		int rc;

		//create one pipe
		rc=pipe(user_to_translator);
		if(rc==-1){
			perror("main: pipe translator_to_user");
			exit(1);
		}

	//create another pipe
	rc=pipe(translator_to_user);
	if(rc==-1){
		perror("main: pipe translator_to_user");
		exit(1);
	}


	pid=fork();

	switch(pid){
		case -1:
			perror("main: fork");
			exit(1);
		case 0:
			translator(user_to_translator, translator_to_user);
		default:
			user_handler(translator_to_user, user_to_translator);
	}

	return 0;
}

